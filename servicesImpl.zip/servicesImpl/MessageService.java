package com.vtl.scm.servicesImpl;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.util.List;

import org.apache.log4j.Logger;

import com.vtl.scm.beans.Message;
import com.vtl.scm.services.IMessageService;
import com.vtl.scm.util.UMFMessaging;

public class MessageService implements IMessageService {

	public static final Logger logger = Logger
			.getLogger("MessageService.class");

	private String umfCliName = null;
	private List<String> umfCliNameList = null;

	private String umfUserName = null;
	private List<String> umfUserNameList = null;

	private String umfPassword = null;
	private List<String> umfPasswordList = null;

	public void init() {

		if (umfCliName != null) {

			String[] arrAllowedClis = umfCliName.split(",");
			for (String allowedCli : arrAllowedClis) {
				umfCliNameList.add(allowedCli);
			}
		}

		if (umfUserName != null) {

			String[] arrAllowedUser = umfUserName.split(",");
			for (String allowedUser : arrAllowedUser) {
				umfUserNameList.add(allowedUser);
			}
		}

		if (umfPassword != null) {

			String[] arrAllowedPwd = umfPassword.split(",");
			for (String allowedPwd : arrAllowedPwd) {
				umfPasswordList.add(allowedPwd);
			}
		}
	}

	@Override
	public String sendMessage(Message message, String transId) {
		String messageStatus = "FALSE";
		try {
			String cli_name = "", snscUsername = "", smscPassword = "";
			cli_name = message.getCli().trim();

			logger.info("[" + transId + "] " + "MSISDN : "
					+ message.getMsisdn() + " CLI : " + message.getCli()
					+ ", Content : " + message.getContent() + ", MessageId : "
					+ message.getId());

			int inx = umfCliNameList.indexOf(cli_name);
			snscUsername = umfUserNameList.get(inx);
			smscPassword = umfPasswordList.get(inx);

			messageStatus = umfMessaging.callUMFInterface(message.getMsisdn(),
					message.getContent(), transId, cli_name, snscUsername,
					smscPassword).toString();

			logger.info("[" + transId + "] " + " Is Message Sent on MSISDN : "
					+ messageStatus);

		} catch (Exception e) {
			StringWriter stack = new StringWriter();
			e.printStackTrace(new PrintWriter(stack));
			logger.error("submitMessage()# Exception :>>" + stack.toString());
		}
		return messageStatus;
	}

	public String getUmfCliName() {
		return umfCliName;
	}

	public void setUmfCliName(String umfCliName) {
		this.umfCliName = umfCliName;
	}

	public List<String> getUmfCliNameList() {
		return umfCliNameList;
	}

	public void setUmfCliNameList(List<String> umfCliNameList) {
		this.umfCliNameList = umfCliNameList;
	}

	public String getUmfUserName() {
		return umfUserName;
	}

	public void setUmfUserName(String umfUserName) {
		this.umfUserName = umfUserName;
	}

	public List<String> getUmfUserNameList() {
		return umfUserNameList;
	}

	public void setUmfUserNameList(List<String> umfUserNameList) {
		this.umfUserNameList = umfUserNameList;
	}

	public String getUmfPassword() {
		return umfPassword;
	}

	public void setUmfPassword(String umfPassword) {
		this.umfPassword = umfPassword;
	}

	public List<String> getUmfPasswordList() {
		return umfPasswordList;
	}

	public void setUmfPasswordList(List<String> umfPasswordList) {
		this.umfPasswordList = umfPasswordList;
	}

	private UMFMessaging umfMessaging;

	public UMFMessaging getUmfMessaging() {
		return umfMessaging;
	}

	public void setUmfMessaging(UMFMessaging umfMessaging) {
		this.umfMessaging = umfMessaging;
	}

}
